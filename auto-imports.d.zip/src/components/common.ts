
export declare type Key = number | string


